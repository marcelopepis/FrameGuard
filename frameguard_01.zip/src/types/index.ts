// Tipos TypeScript compartilhados
