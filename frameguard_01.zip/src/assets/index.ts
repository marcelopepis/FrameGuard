// Imagens, ícones e fontes
