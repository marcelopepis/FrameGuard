import { BrowserRouter, useLocation, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import { Dashboard, Optimizations, Cleanup, HealthCheck, Plans, Settings } from './pages';
import { GlobalRunningProvider } from './contexts/RunningContext';

// Todas as rotas declaradas aqui. A ordem determina a renderização no DOM.
const ROUTES = [
  { path: '/',              Page: Dashboard },
  { path: '/optimizations', Page: Optimizations },
  { path: '/cleanup',       Page: Cleanup },
  { path: '/health',        Page: HealthCheck },
  { path: '/plans',         Page: Plans },
  { path: '/settings',      Page: Settings },
];

// Renderiza todas as páginas simultaneamente usando keep-alive:
// páginas inativas ficam ocultas via CSS (display: none), mas permanecem
// montadas — preservando estado React, execuções em andamento e listeners Tauri.
function Pages() {
  const { pathname } = useLocation();
  const isKnown = ROUTES.some(r => r.path === pathname);

  return (
    <Layout>
      {!isKnown && <Navigate to="/" replace />}
      {ROUTES.map(({ path, Page }) => (
        <div key={path} style={{ display: pathname === path ? 'contents' : 'none' }}>
          <Page />
        </div>
      ))}
    </Layout>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <GlobalRunningProvider>
        <Pages />
      </GlobalRunningProvider>
    </BrowserRouter>
  );
}
